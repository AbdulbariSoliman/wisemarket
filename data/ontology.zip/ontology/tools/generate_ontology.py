import os
import csv

BASE_DIR = "data/ontology"
os.makedirs(BASE_DIR, exist_ok=True)

FILES = {
    "allergens.csv": [
        ["allergen","en","de","fr","it"],
        ["crustaceans","shrimp; prawn; crab; lobster","Krebstiere; Garnele; Krabbe; Hummer","crustacés; crevette; crabe; homard","crostacei; gambero; granchio; aragosta"],
        ["celery","celery; celeriac","Sellerie; Knollensellerie","céleri","sedano"],
        ["mustard","mustard; mustard seed","Senf; Senfkorn","moutarde","senape"],
        ["sesame","sesame; sesame seeds","Sesam; Sesamsamen","sésame","sesamo"],
        ["sulphites","sulphites; sulfur dioxide; E220","Sulfite; Schwefeldioxid","sulfites; dioxyde de soufre","solfiti; biossido di zolfo"],
        ["lupin","lupin; lupine","Lupinen","lupin","lupino"],
        ["gluten","wheat; rye; barley; spelt; kamut; triticale; einkorn; emmer; malt; couscous; bulgur","Weizen; Roggen; Gerste; Dinkel; Kamut; Triticale; Einkorn; Emmer; Malz; Couscous; Bulgur","blé; seigle; orge; épeautre; kamut; triticale; engrain; amidonnier; malt; couscous; boulgour","frumento; segale; orzo; farro; kamut; triticale; piccolo farro; farro medio; malto; couscous; bulgur"],
        ["milk","milk; lactose; whey; casein; butter; cream; yogurt","Milch; Laktose; Molke; Kasein; Butter; Rahm; Joghurt","lait; lactose; lactosérum; caséine; beurre; crème; yaourt","latte; lattosio; siero di latte; caseina; burro; panna; yogurt"],
        ["eggs","eggs; albumin; yolk; lysozyme","Eier; Albumin; Eigelb; Lysozym","œufs; albumine; jaune d'œuf; lysozyme","uova; albume; tuorlo; lisozima"],
        ["fish","fish; salmon; cod; tuna; anchovy","Fisch; Lachs; Kabeljau; Thunfisch; Sardellen","poisson; saumon; cabillaud; thon; anchois","pesce; salmone; merluzzo; tonno; acciughe"],
        ["soy","soy; tofu; miso; tempeh","Soja; Tofu; Miso; Tempeh","soja; tofu; miso; tempeh","soia; tofu; miso; tempeh"],
        ["nuts","almond; hazelnut; walnut; cashew; pecan; pistachio","Mandeln; Haselnüsse; Walnüsse; Cashew; Pistazien","amandes; noisettes; noix; cajou; pistaches","mandorle; nocciole; noci; anacardi; pistacchi"],
        ["molluscs","mussels; clams; oysters; squid; octopus","Muscheln; Austern; Tintenfisch; Oktopus","moules; huîtres; calmar; poulpe","cozze; ostriche; calamaro; polpo"],
    ],
    "pork.csv": [
        ["term","en","de","fr","it"],
        ["pork","pork; porcine","Schwein; Schweinefleisch","porc; viande de porc","maiale; carne di maiale"],
        ["bacon","bacon; pancetta","Speck; Pancetta","bacon; pancetta","bacon; pancetta"],
        ["ham","ham; prosciutto","Schinken; Prosciutto","jambon","prosciutto"],
        ["gelatine_pork","pork gelatine","Schweinegelatine","gélatine porcine","gelatina suina"],
        ["lard","lard; pork fat","Schweineschmalz","saindoux","strutto"],
    ],
    "alcohol.csv": [
        ["term","en","de","fr","it"],
        ["ethanol","alcohol; ethanol","Alkohol; Ethanol","alcool; éthanol","alcol; etanolo"],
        ["wine","wine; sherry; port","Wein; Sherry; Portwein","vin; porto","vino; porto"],
        ["beer","beer; lager; ale","Bier; Lager; Ale","bière","birra"],
        ["spirits","rum; gin; vodka","Rum; Gin; Wodka","rhum; gin; vodka","rum; gin; vodka"],
    ],
    "additives.csv": [
        ["term","en","de","fr","it"],
        ["emulsifier","emulsifier; lecithin; E322","Emulgator; Lecithin","émulsifiant; lécithine","emulsionante; lecitina"],
        ["stabilizer","stabilizer; pectin; xanthan","Stabilisator; Pektin; Xanthan","stabilisant; pectine","stabilizzante; pectina"],
        ["thickener","thickener; guar gum","Verdickungsmittel; Guarkernmehl","épaississant; gomme de guar","addensante; gomma di guar"],
        ["colorant","colorant; E100-E199","Farbstoff; E100-E199","colorant; E100-E199","colorante; E100-E199"],
        ["flavor_enhancer","flavor enhancer; MSG","Geschmacksverstärker; Glutamat","exhausteur de goût","esaltatore di sapidità"],
    ],
    "sugar_synonyms.csv": [
        ["term","en","de","fr","it"],
        ["sugar","sugar; sucrose","Zucker; Saccharose","sucre; saccharose","zucchero; saccarosio"],
        ["glucose","glucose","Glukose","glucose","glucosio"],
        ["fructose","fructose","Fruktose","fructose","fruttosio"],
        ["syrup","syrup; maple syrup","Sirup; Ahornsirup","sirop; sirop d'érable","sciroppo; sciroppo d'acero"],
    ],
    "vegan_markers.csv": [
        ["term","en","de","fr","it"],
        ["vegan","vegan; plant based","vegan; pflanzlich","végan; végétal","vegano; vegetale"],
        ["no_animal","no animal ingredients","keine tierischen Zutaten","sans ingrédients animaux","senza ingredienti animali"],
    ],
    "vegetarian_markers.csv": [
        ["term","en","de","fr","it"],
        ["vegetarian","vegetarian","vegetarisch","végétarien","vegetariano"],
        ["ovo_lacto","ovo-lacto vegetarian","ovo-lacto vegetarisch","ovo-lacto végétarien","ovo-latto vegetariano"],
    ],
    "ancient_grains.csv": [
        ["term","en","de","fr","it"],
        ["quinoa","quinoa","Quinoa","quinoa","quinoa"],
        ["amaranth","amaranth","Amaranth","amarante","amaranto"],
        ["millet","millet","Hirse","millet","miglio"],
        ["spelt","spelt; dinkel","Dinkel","épeautre","farro"],
        ["buckwheat","buckwheat","Buchweizen","sarrasin","grano saraceno"],
    ],
    "sports_nutrition_markers.csv": [
        ["term","en","de","fr","it"],
        ["whey","whey protein","Molkenprotein","lactosérum","siero di latte"],
        ["isolate","protein isolate","Isolat","isolat","isolato"],
        ["bcaa","BCAA; amino acids","BCAA; Aminosäuren","BCAA","BCAA"],
        ["electrolytes","electrolytes","Elektrolyte","électrolytes","elettroliti"],
    ],
}

for filename, rows in FILES.items():
    path = os.path.join(BASE_DIR, filename)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(rows)
    print(f"Created: {path}")

print("✅ Ontology generation complete.")